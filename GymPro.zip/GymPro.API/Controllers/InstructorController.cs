﻿using GymPro.Core.DTOs;
using GymPro.Core.Interaces.IService;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

[Route("api/[controller]")]
[ApiController]
public class InstructorController : ControllerBase
{
    private readonly IInstructorService _service;
    public InstructorController(IInstructorService service)
    {
        _service = service;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var instructors = await _service.GetAllInstructorsAsync();
        return Ok(instructors);
    }

    [HttpGet("{id}")]
    [Authorize(Roles = "Admin")]

    public async Task<IActionResult> GetById(int id)
    {
        var instructor = await _service.GetInstructorByIdAsync(id);
        if (instructor == null) return NotFound();
        return Ok(instructor);
    }

    [HttpPost]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Create(InstructorDto dto)
    {
        var created = await _service.AddInstructorAsync(dto);
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
    }

    [HttpPut("{id}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Update(int id, InstructorDto dto)
    {
        dto.Id = id;
        var updated = await _service.UpdateInstructorAsync(dto);
        if (updated == null) return NotFound();
        return Ok(updated);
    }

    [HttpDelete("{id}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Delete(int id)
    {
        var deleted = await _service.DeleteInstructorAsync(id);
        if (!deleted) return NotFound();
        return NoContent();
    }
}
