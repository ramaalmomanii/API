﻿using GymPro.Core.DTOs;
using GymPro.Core.Interaces.IService;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace GymPro.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]

    public class BookingController: ControllerBase
    {
        private readonly IBookingService _bookingService;
        public BookingController(IBookingService bookingService)
        {
            _bookingService = bookingService;
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public IActionResult GetAllBookings()
        {
            var bookings = _bookingService.GetAllBookingsAsync();
            return Ok(bookings);
        }

        [HttpGet("{id}")]
        [Authorize(Roles = "Admin, User")]
        public async Task<IActionResult> GetBookingById(int id)
        {
            var booking = await _bookingService.GetBookingByIdAsync(id);
            if (booking == null)
            {
                return NotFound($"Booking with ID {id} not found.");
            }
            return Ok(booking);
        }

        [HttpPost]
        [Authorize(Roles = "Admin, User")]
        public async Task<IActionResult> CreateBooking([FromBody] BookingDto bookingDto)
        {
            if (bookingDto == null)
            {
                return BadRequest("Booking data is required.");
            }
            var createdBooking = await _bookingService.AddAsync(bookingDto);
            return CreatedAtAction(nameof(GetBookingById), new { id = createdBooking.Id }, createdBooking);
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Admin, User")]
        public async Task<IActionResult> UpdateBooking(int id, [FromBody] BookingDto bookingDto)
        {
            if (bookingDto == null || bookingDto.Id != id)
            {
                return BadRequest("Booking data is invalid.");
            }
            var updatedBooking = await _bookingService.UpdateAsync(bookingDto);
            if (updatedBooking == null)
            {
                return NotFound($"Booking with ID {id} not found.");
            }
            return Ok(updatedBooking);
        }


        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin,User")]
        public async Task<IActionResult> DeleteBooking(int id)
        {
            var booking = await _bookingService.GetBookingByIdAsync(id);
            if (booking == null)
                return NotFound($"Booking with ID {id} not found.");

            var currentUserRole = User.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value;
            var currentUserId = int.Parse(User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value);

            if (currentUserRole == "User" && booking.UserId != currentUserId)
                return Forbid("You can only delete your own bookings.");

            var deleted = await _bookingService.DeleteAsync(id);
            if (!deleted)
                return StatusCode(500, "Error deleting booking.");

            return NoContent();
        }

    }
}
