﻿using GymPro.Core.DTOs;
using GymPro.Core.Interaces;
using GymPro.Core.Interaces.IService;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;


namespace GymPro.API.Controllers
{       
    
        [ApiController]
        [Route("api/[controller]")]
    public class AuthController : ControllerBase // Inherit from ControllerBase to access Ok() and BadRequest()
    {
        private readonly IAuthService _svc;
        public AuthController(IAuthService svc) => _svc = svc;

        [HttpPost("register")]
        [AllowAnonymous]

        [Authorize(Roles = "Customer")]
        public async Task<IActionResult> Register(RegisterDto dto)
        {
            var authResponse = await _svc.RegisterAsync(dto);
            return authResponse == null
                ? BadRequest("Username already exists.")
                : Ok(authResponse);
        }

        [HttpPost("login")]
        [AllowAnonymous]
        [Authorize(Roles = "Admin,Customer")]
        public async Task<IActionResult> Login(LoginDto dto)
        {
            var auth = await _svc.LoginAsync(dto);
            return auth == null ? Unauthorized("Invalid username or password.") : Ok(auth);
        }
    }
}
