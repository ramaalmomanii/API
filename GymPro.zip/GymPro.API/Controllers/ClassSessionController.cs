﻿using GymPro.Core.DTOs;
using GymPro.Core.Interaces.IService;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

[Route("api/[controller]")]
[ApiController]
public class ClassSessionController : ControllerBase
{
    private readonly IClassSessionService _service;
    public ClassSessionController(IClassSessionService service)
    {
        _service = service;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var sessions = await _service.GetAllSessionsAsync();
        return Ok(sessions);
    }

    [HttpGet("{id}")]
    [Authorize(Roles = "Admin")]

    public async Task<IActionResult> GetById(int id)
    {
        var session = await _service.GetSessionByIdAsync(id);
        if (session == null) return NotFound();
        return Ok(session);
    }

    [HttpPost]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Create(ClassSessionDto dto)
    {
        var created = await _service.AddSessionAsync(dto);
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
    }

    [HttpPut("{id}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Update(int id, ClassSessionDto dto)
    {
        dto.Id = id;
        var updated = await _service.UpdateSessionAsync(dto);
        if (updated == null) return NotFound();
        return Ok(updated);
    }

    [HttpDelete("{id}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Delete(int id)
    {
        var deleted = await _service.DeleteSessionAsync(id);
        if (!deleted) return NotFound();
        return NoContent();
    }
}
