﻿using GymPro.Core.DTOs;
using GymPro.Core.Interaces.IService;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

[Route("api/[controller]")]
[ApiController]
public class ClassController : ControllerBase
{
    private readonly IClassService _service;
    public ClassController(IClassService service)
    {
        _service = service;
    }
    //CRUD ADMIN ..........
    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var classes = await _service.GetAllClassesAsync();
        return Ok(classes);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var cls = await _service.GetClassByIdAsync(id);
        if (cls == null) return NotFound();
        return Ok(cls);
    }

    [HttpPost]
    [Authorize(Roles = "Admin")] 
    public async Task<IActionResult> Create(ClassDto dto)
    {
        var created = await _service.AddClassAsync(dto);
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
    }

    [HttpPut("{id}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Update(int id, ClassDto dto)
    {
        dto.Id = id;
        var updated = await _service.UpdateClassAsync(dto);
        if (updated == null) return NotFound();
        return Ok(updated);
    }

    [HttpDelete("{id}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Delete(int id)
    {
        var deleted = await _service.DeleteClassAsync(id);
        if (!deleted) return NotFound();
        return NoContent();
    }
}
