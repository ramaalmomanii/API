﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymPro.Core.DTOs
{
    public class AuthResponseDto
    {
        public String Token { get; set; } = "";
        public string Role { get; set; } = "";
        public string Email { get; set; } = "";
        public DateTime Expiration { get; set; } = DateTime.Now.AddHours(1); // Default expiration time of 1 hour
    }
}
