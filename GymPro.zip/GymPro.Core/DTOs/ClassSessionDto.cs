﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymPro.Core.DTOs
{
    public class ClassSessionDto
    {
        public int Id { get; set; }
        public int InstructorId { get; set; } // ID of the instructor conducting the class session
        public int Userid { get; set; }
        public int ClassId { get; set; }
        public DateTime StartAt { get; set; }
        public DateTime EndAt { get; set; }
        public int Capacity { get; set; } = 20; // Maximum number of participants allowed in the class session
        public string Room { get; set; } = "";
        public byte RowVerSion { get; set; } = 0; // Used for concurrency control
        public byte ConcurrencyToken { get; set; } = 0; // Used for concurrency control


    }
}
