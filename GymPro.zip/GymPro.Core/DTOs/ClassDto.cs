﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymPro.Core.DTOs
{
    public class ClassDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Type { get; set; }
        public Decimal DurationMinutes { get; set; } = 0;
        

        public int InstructorId { get; set; }
        public string InstructorFullName { get; set; } = "";


    }
}
