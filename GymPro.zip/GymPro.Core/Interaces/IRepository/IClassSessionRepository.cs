﻿using GymPro.Core.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GymPro.Core.Interaces.IRepository
{
    public interface IClassSessionRepository
    {
        Task<List<ClassSession>> GetAllSessionsAsync();
        Task<ClassSession?> GetSessionByIdAsync(int id);
        Task<ClassSession> AddSessionAsync(ClassSession session);
        Task<ClassSession?> UpdateSessionAsync(ClassSession session);
        Task<bool> DeleteSessionAsync(int id);
    }
}
