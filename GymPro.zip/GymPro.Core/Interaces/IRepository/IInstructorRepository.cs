﻿using GymPro.Core.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GymPro.Core.Interaces.IRepository
{
    public interface IInstructorRepository
    {
        Task<List<Instructor>> GetAllInstructorsAsync();
        Task<Instructor?> GetInstructorByIdAsync(int id);
        Task<Instructor> AddInstructorAsync(Instructor instructor);
        Task<Instructor?> UpdateInstructorAsync(Instructor instructor);
        Task<bool> DeleteInstructorAsync(int id);
    }
}
