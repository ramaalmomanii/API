﻿using GymPro.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymPro.Core.Interaces.IRepository
{
     public interface IClassRepository
    {
        public Task<List<Class>> GetAllClassesAsync();
        public Task<Class?> GetClassByIdAsync(int id);
        public Task<Class> AddClassAsync(Class classEntity);
        public Task<Class?> UpdateClassAsync(Class classEntity);
        public Task<bool> DeleteClassAsync(int id);
      //  public Task<IEnumerable<Class>> GetClassesByTrainerIdAsync(int trainerId);
    }
}
