﻿using GymPro.Core.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymPro.Core.Interaces.IService
{
    public interface IBookingService
    {
        /*Task<List<Booking>> GetAllBookingsAsync();
        Task<Booking> GetBookingByIdAsync(int id);
        Task<Booking> UpdateAsync(Booking newBooking);
        Task<Booking> AddAsync(Booking booking); //Creates a new booking
        Task<bool> DeleteAsync(int id);   //Cancel a booking
         */
        Task<List<BookingDto>> GetAllBookingsAsync();
        Task<BookingDto?> GetBookingByIdAsync(int id);
        Task<BookingDto?> UpdateAsync(BookingDto newBooking);
        Task<bool> DeleteAsync(int id);
        Task<BookingDto?> AddAsync(BookingDto booking); //Creates a new booking
    }
}
