﻿using GymPro.Core.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymPro.Core.Interaces.IService
{
    public interface IClassService
    {
        Task<List<ClassDto>> GetAllClassesAsync();
         Task<ClassDto?> GetClassByIdAsync(int id);
        Task<ClassDto> AddClassAsync(ClassDto classDto);
        Task<ClassDto?> UpdateClassAsync(ClassDto classDto);
        Task<bool> DeleteClassAsync(int id);

    }
}
