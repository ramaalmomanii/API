﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GymPro.Core.DTOs;
using GymPro.Core.Entities;

namespace GymPro.Core.Interaces.IService
{
    public interface IUserService
    {
        Task<List<UserDto?>> GetAllUserAsync();
        Task<AuthResponseDto> RegisterAsync(RegisterDto dto);
        Task<AuthResponseDto> LoginAsync(LoginDto dto);
        Task<bool> EmailExistAsync(string email);
        Task<User?> GetUserByIdAsync(int id);
        Task<User?> GetUserByEmailAsync(string email);
        Task<User?> UpdateUserAsync(User user);
        Task<bool> DeleteUserAsync(int id);

    }
}
