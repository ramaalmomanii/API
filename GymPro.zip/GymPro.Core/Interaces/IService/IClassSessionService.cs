﻿using GymPro.Core.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GymPro.Core.Interaces.IService
{
    public interface IClassSessionService
    {
        Task<List<ClassSessionDto>> GetAllSessionsAsync();
        Task<ClassSessionDto?> GetSessionByIdAsync(int id);
        Task<ClassSessionDto> AddSessionAsync(ClassSessionDto dto);
        Task<ClassSessionDto?> UpdateSessionAsync(ClassSessionDto dto);
        Task<bool> DeleteSessionAsync(int id);
    }
}
