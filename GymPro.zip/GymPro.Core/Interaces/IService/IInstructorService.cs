﻿using GymPro.Core.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GymPro.Core.Interaces.IService
{
    public interface IInstructorService
    {
        Task<List<InstructorDto>> GetAllInstructorsAsync();
        Task<InstructorDto?> GetInstructorByIdAsync(int id);
        Task<InstructorDto> AddInstructorAsync(InstructorDto dto);
        Task<InstructorDto?> UpdateInstructorAsync(InstructorDto dto);
        Task<bool> DeleteInstructorAsync(int id);
    }
}
