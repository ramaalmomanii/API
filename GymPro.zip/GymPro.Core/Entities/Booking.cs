﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymPro.Core.Entities
{
    public class Booking
    {
        public int Id { get; set; }
        public DateTime BookingDate { get; set; } = DateTime.Now;
        public string Status { get; set; } = "Pending"; // e.g., "Pending", "Confirmed", "Cancelled"
        public int UserId { get; set; }
        public int ClassId { get; set; }
        public int ClassSessionId { get; set; } // Assuming a class can have multiple sessions
       
        
        // Navigation properties
        public User User { get; set; } = null!;
        public ClassSession ClassSession { get; set; } = null!;
    }
}
