﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
namespace GymPro.Core.Entities
{
    [Index(nameof(Username), IsUnique = true)]
    [Index(nameof(Email), IsUnique = true)]
    public class User
    {
        public int Id { get; set; } 
        public string FullName { get; set; } = "";
        public string Username { get; set; } = ""; //Required for login & it must be unique
        public string Password { get; set; } = "";
        public string Email { get; set; } = "";
        public string Role { get; set; } = "";// e.g., "Admin", "Member"
        public DateTime CreatedDate { get; set; } = DateTime.Now;

        //Navigation 
        public ICollection<Booking> Bookings { get; set; } = new List<Booking>();
    }
}
