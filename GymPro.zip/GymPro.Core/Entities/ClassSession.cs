﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymPro.Core.Entities
{
    public class ClassSession
    {
        public int Id { get; set; }
        public int ClassId { get; set; }
        public DateTime StartAt { get; set; }
        public DateTime EndAt { get; set; }
        public int Capacity { get; set; } = 20; // Maximum participants
        public string Room { get; set; } = "";

        // Concurrency control
        [Timestamp]
        public byte[] RowVersion { get; set; } = null!;


        // Navigation properties

        // FK to Class
        public Class Class { get; set; }  
        // FK to Instructor
        public int InstructorId { get; set; }
        public Instructor Instructor { get; set; }
        // Collection of bookings for this session
        public ICollection<Booking> Bookings { get; set; } = new List<Booking>();
    }
}
