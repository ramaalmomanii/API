﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymPro.Core.Entities
{
    public class Class
    {
        public int Id { get; set; }
        public string Type { get; set; } = ""; 
        public string Description { get; set; } = "";
        public Decimal DurationMinutes { get; set; } = 0;
        //public DateTime StartTime { get; set; }
        //public DateTime EndTime { get; set; }
         
        // Navigation properties
        public ICollection<Instructor> Instructors { get; set; } = new List<Instructor>();
        public ICollection<ClassSession> ClassSessions { get; set; } = new List<ClassSession>();
    }
}
