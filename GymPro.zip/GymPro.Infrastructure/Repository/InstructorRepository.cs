﻿using GymPro.Core.Entities;
using GymPro.Core.Interaces.IRepository;
using GymPro.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GymPro.Infrastructure.Repository
{
    public class InstructorRepository : IInstructorRepository
    {
        private readonly AppDbContext _context;
        public InstructorRepository(AppDbContext context) => _context = context;

        public async Task<List<Instructor>> GetAllInstructorsAsync() =>
            await _context.Instructors.Include(i => i.Class).ToListAsync();

        public async Task<Instructor?> GetInstructorByIdAsync(int id) =>
            await _context.Instructors.Include(i => i.Class)
                .FirstOrDefaultAsync(i => i.Id == id);

        public async Task<Instructor> AddInstructorAsync(Instructor instructor)
        {
            await _context.Instructors.AddAsync(instructor);
            await _context.SaveChangesAsync();
            return instructor;
        }

        public async Task<Instructor?> UpdateInstructorAsync(Instructor instructor)
        {
            var existing = await _context.Instructors.FindAsync(instructor.Id);
            if (existing == null) return null;

            existing.FullName = instructor.FullName;
            existing.Bio = instructor.Bio;
            existing.ClassId = instructor.ClassId;

            _context.Instructors.Update(existing);
            await _context.SaveChangesAsync();
            return existing;
        }

        public async Task<bool> DeleteInstructorAsync(int id)
        {
            var instructor = await _context.Instructors.FindAsync(id);
            if (instructor == null) return false;

            _context.Instructors.Remove(instructor);
            return await _context.SaveChangesAsync() > 0;
        }
    }
}
