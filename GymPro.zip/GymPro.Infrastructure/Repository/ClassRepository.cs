﻿using GymPro.Core.Entities;
using GymPro.Core.Interaces.IRepository;
using GymPro.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GymPro.Infrastructure.Repository
{
    public class ClassRepository : IClassRepository
    {
        private readonly AppDbContext _context;
        public ClassRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Class>> GetAllClassesAsync()
        {
            return await _context.Classes.ToListAsync();
        }

        public async Task<Class?> GetClassByIdAsync(int id)
        {
            return await _context.Classes.FindAsync(id);
        }

        public async Task<Class> AddClassAsync(Class classEntity)
        {
            await _context.Classes.AddAsync(classEntity);
            await _context.SaveChangesAsync();
            return classEntity;
        }

        public async Task<Class?> UpdateClassAsync(Class classEntity)
        {
            var existing = await _context.Classes.FindAsync(classEntity.Id);
            if (existing == null) return null;

            existing.Type = classEntity.Type;
            existing.Description = classEntity.Description;
            existing.DurationMinutes = classEntity.DurationMinutes;

            _context.Classes.Update(existing);
            await _context.SaveChangesAsync();
            return existing;
        }

        public async Task<bool> DeleteClassAsync(int id)
        {
            var existing = await _context.Classes.FindAsync(id);
            if (existing == null) return false;

            _context.Classes.Remove(existing);
            var deleted = await _context.SaveChangesAsync();
            return deleted > 0;
        }
    }
}
