﻿using GymPro.Core.Entities;
using GymPro.Core.Interaces.IRepository;
using GymPro.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GymPro.Infrastructure.Repository
{
    public class ClassSessionRepository : IClassSessionRepository
    {
        private readonly AppDbContext _context;
        public ClassSessionRepository(AppDbContext context) => _context = context;

        public async Task<List<ClassSession>> GetAllSessionsAsync() =>
            await _context.ClassSessions.Include(cs => cs.Class).Include(cs => cs.Instructor).ToListAsync();

        public async Task<ClassSession?> GetSessionByIdAsync(int id) =>
            await _context.ClassSessions.Include(cs => cs.Class).Include(cs => cs.Instructor)
                .FirstOrDefaultAsync(cs => cs.Id == id);

        public async Task<ClassSession> AddSessionAsync(ClassSession session)
        {
            await _context.ClassSessions.AddAsync(session);
            await _context.SaveChangesAsync();
            return session;
        }

        public async Task<ClassSession?> UpdateSessionAsync(ClassSession session)
        {
            var existing = await _context.ClassSessions.FindAsync(session.Id);
            if (existing == null) return null;

            existing.ClassId = session.ClassId;
            existing.InstructorId = session.InstructorId;
            existing.StartAt = session.StartAt;
            existing.EndAt = session.EndAt;
            existing.Capacity = session.Capacity;
            existing.Room = session.Room;

            _context.ClassSessions.Update(existing);
            await _context.SaveChangesAsync();
            return existing;
        }

        public async Task<bool> DeleteSessionAsync(int id)
        {
            var session = await _context.ClassSessions.FindAsync(id);
            if (session == null) return false;

            _context.ClassSessions.Remove(session);
            return await _context.SaveChangesAsync() > 0;
        }
    }
}
