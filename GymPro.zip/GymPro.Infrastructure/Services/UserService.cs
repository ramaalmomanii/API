﻿using GymPro.Core.DTOs;
using GymPro.Core.Entities;
using GymPro.Core.Interaces.IRepository;
using GymPro.Core.Interaces.IService;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GymPro.Infrastructure.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;

        public UserService(IUserRepository repo)
        {
            _userRepository = repo;
        }

        // Get all users
        public async Task<List<UserDto?>> GetAllUserAsync()
        {
            var users = await _userRepository.GetAllUserAsync();
            return users.Select(u => new UserDto
            {
                Id = u.Id,
                FullName = u.FullName,
                Username = u.Username,
                Email = u.Email,
                Role = u.Role
            }).ToList();
        }

        // Get user by Id
        public async Task<User?> GetUserByIdAsync(int id)
        {
            return await _userRepository.GetByIdAsync(id);
        }

        // Get user by email
        public async Task<User?> GetUserByEmailAsync(string email)
        {
            return await _userRepository.GetByEmailAsync(email);
        }

        // Check if email exists
        public async Task<bool> EmailExistAsync(string email)
        {
            return (bool)await _userRepository.EmailExistAsync(email);
        }

       


        // Update user
        public async Task<User?> UpdateUserAsync(User user)
        {
            var existingUser = await _userRepository.GetByIdAsync(user.Id);
            if (existingUser == null) return null;

            existingUser.FullName = user.FullName;
            existingUser.Username = user.Username;
            existingUser.Email = user.Email;
            existingUser.Role = user.Role;

            return await _userRepository.UpdateAsync(existingUser);
        }

        // Register new user
        public async Task<AuthResponseDto> RegisterAsync(RegisterDto dto)
        {
            if (await EmailExistAsync(dto.Email))
                throw new Exception("Email already registered");

            var user = new User
            {
                FullName = dto.FullName,
                //Username = dto.Username,
                Email = dto.Email,
                Password = dto.Password, 
                Role = "User"
            };

            var createdUser = await _userRepository.AddAsync(user);
            if (createdUser == null) return null;

            return new AuthResponseDto
            {
                Email = createdUser.Email,
                Role = createdUser.Role
            };
        }

        // Login 
        public async Task<AuthResponseDto> LoginAsync(LoginDto dto)
        {
            var user = await _userRepository.GetByEmailAsync(dto.Email);
            if (user == null || user.Password != dto.Password) 
                throw new Exception("Invalid email or password");

            return new AuthResponseDto
            {
                Email = user.Email,
                Role = user.Role
            };
        }

        public async Task<bool> DeleteUserAsync(int id)
        {
            var user = await _userRepository.GetByIdAsync(id);
            if (user == null) return false;

            var us = await _userRepository.DeleteAsync(id);
            return true;


        }
    }
}
