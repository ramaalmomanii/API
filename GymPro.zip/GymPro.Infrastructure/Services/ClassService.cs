﻿using GymPro.Core.DTOs;
using GymPro.Core.Entities;
using GymPro.Core.Interaces.IRepository;
using GymPro.Core.Interaces.IService;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GymPro.Infrastructure.Service
{
    public class ClassService : IClassService
    {
        private readonly IClassRepository _repo;
        public ClassService(IClassRepository repo)
        {
            _repo = repo;
        }

        public async Task<List<ClassDto>> GetAllClassesAsync()
        {
            var classes = await _repo.GetAllClassesAsync();
            return classes.Select(c => new ClassDto
            {
                Id = c.Id,
                Name = c.Type, 
                Type = c.Type,
                Description = c.Description,
                DurationMinutes = c.DurationMinutes,
                InstructorId = c.Instructors.FirstOrDefault()?.Id ?? 0,
                InstructorFullName = c.Instructors.FirstOrDefault()?.FullName ?? ""
            }).ToList();
        }

        public async Task<ClassDto?> GetClassByIdAsync(int id)
        {
            var c = await _repo.GetClassByIdAsync(id);
            if (c == null) return null;

            return new ClassDto
            {
                Id = c.Id,
                Name = c.Type,
                Type = c.Type,
                Description = c.Description,
                DurationMinutes = c.DurationMinutes,
                InstructorId = c.Instructors.FirstOrDefault()?.Id ?? 0,
                InstructorFullName = c.Instructors.FirstOrDefault()?.FullName ?? ""
            };
        }

        public async Task<ClassDto> AddClassAsync(ClassDto classDto)
        {
            var entity = new Class
            {
                Type = classDto.Type,
                Description = classDto.Description,
                DurationMinutes = classDto.DurationMinutes
            };
            var added = await _repo.AddClassAsync(entity);

            classDto.Id = added.Id;
            return classDto;
        }

        public async Task<ClassDto?> UpdateClassAsync(ClassDto classDto)
        {
            var entity = new Class
            {
                Id = classDto.Id,
                Type = classDto.Type,
                Description = classDto.Description,
                DurationMinutes = classDto.DurationMinutes
            };

            var updated = await _repo.UpdateClassAsync(entity);
            if (updated == null) return null;

            classDto.Id = updated.Id;
            return classDto;
        }

        public async Task<bool> DeleteClassAsync(int id)
        {
            return await _repo.DeleteClassAsync(id);
        }
    }
}
