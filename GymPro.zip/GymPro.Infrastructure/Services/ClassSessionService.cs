﻿using GymPro.Core.DTOs;
using GymPro.Core.Entities;
using GymPro.Core.Interaces.IRepository;
using GymPro.Core.Interaces.IService;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GymPro.Infrastructure.Service
{
    public class ClassSessionService : IClassSessionService
    {
        private readonly IClassSessionRepository _repo;
        public ClassSessionService(IClassSessionRepository repo) => _repo = repo;

        public async Task<List<ClassSessionDto>> GetAllSessionsAsync()
        {
            var sessions = await _repo.GetAllSessionsAsync();
            return sessions.Select(cs => new ClassSessionDto
            {
                Id = cs.Id,
                ClassId = cs.ClassId,
                InstructorId = cs.InstructorId,
                StartAt = cs.StartAt,
                EndAt = cs.EndAt,
                Capacity = cs.Capacity,
                Room = cs.Room
            }).ToList();
        }

        public async Task<ClassSessionDto?> GetSessionByIdAsync(int id)
        {
            var cs = await _repo.GetSessionByIdAsync(id);
            if (cs == null) return null;

            return new ClassSessionDto
            {
                Id = cs.Id,
                ClassId = cs.ClassId,
                InstructorId = cs.InstructorId,
                StartAt = cs.StartAt,
                EndAt = cs.EndAt,
                Capacity = cs.Capacity,
                Room = cs.Room
            };
        }

        public async Task<ClassSessionDto> AddSessionAsync(ClassSessionDto dto)
        {
            var session = new ClassSession
            {
                ClassId = dto.ClassId,
                InstructorId = dto.InstructorId,
                StartAt = dto.StartAt,
                EndAt = dto.EndAt,
                Capacity = dto.Capacity,
                Room = dto.Room
            };

            var created = await _repo.AddSessionAsync(session);
            dto.Id = created.Id;
            return dto;
        }

        public async Task<ClassSessionDto?> UpdateSessionAsync(ClassSessionDto dto)
        {
            var session = new ClassSession
            {
                Id = dto.Id,
                ClassId = dto.ClassId,
                InstructorId = dto.InstructorId,
                StartAt = dto.StartAt,
                EndAt = dto.EndAt,
                Capacity = dto.Capacity,
                Room = dto.Room
            };

            var updated = await _repo.UpdateSessionAsync(session);
            if (updated == null) return null;

            return dto;
        }

        public async Task<bool> DeleteSessionAsync(int id) => await _repo.DeleteSessionAsync(id);
    }
}
