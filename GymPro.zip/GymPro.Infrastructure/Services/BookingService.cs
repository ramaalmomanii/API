﻿using GymPro.Core.DTOs;
using GymPro.Core.Interaces.IRepository;
using GymPro.Core.Interaces.IService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymPro.Infrastructure.Services
{
    public class BookingService:IBookingService

    {
        private readonly IBookingRepository _repo;
        public BookingService(IBookingRepository repo)
        {
            _repo = repo;
        }
        public async Task<List<BookingDto>> GetAllBookingsAsync()
        {
            var bookings = await _repo.GetAllBookingsAsync();
            return bookings.Select(b => new BookingDto
            {
                Id = b.Id,
                BookingDate = b.BookingDate,
                Status = b.Status,
                UserId = b.UserId,
                ClassId = b.ClassId,
                ClassSessionId = b.ClassSessionId
            }).ToList();
        }
        public async Task<BookingDto?> GetBookingByIdAsync(int id)
        {
            var booking = await _repo.GetBookingByIdAsync(id);
            if (booking == null) return null;
            return new BookingDto
            {
                Id = booking.Id,
                BookingDate = booking.BookingDate,
                Status = booking.Status,
                UserId = booking.UserId,
                ClassId = booking.ClassId,
                ClassSessionId = booking.ClassSessionId
            };
        }
        public async Task<BookingDto?> UpdateAsync(BookingDto newBooking)
        {
            var booking = await _repo.GetBookingByIdAsync(newBooking.Id);
            if (booking == null) return null;
            booking.BookingDate = newBooking.BookingDate;
            booking.Status = newBooking.Status;
            booking.UserId = newBooking.UserId;
            booking.ClassId = newBooking.ClassId;
            booking.ClassSessionId = newBooking.ClassSessionId;
            var updatedBooking = await _repo.UpdateAsync(booking);
            return new BookingDto
            {
                Id = updatedBooking.Id,
                BookingDate = updatedBooking.BookingDate,
                Status = updatedBooking.Status,
                UserId = updatedBooking.UserId,
                ClassId = updatedBooking.ClassId,
                ClassSessionId = updatedBooking.ClassSessionId
            };
        }
        public async Task<bool> DeleteAsync(int id)
        {
            return await _repo.DeleteAsync(id);
        }
        public async Task<BookingDto?> AddAsync(BookingDto booking)
        {
            var newBooking = new Core.Entities.Booking
            {
                BookingDate = booking.BookingDate,
                Status = booking.Status,
                UserId = booking.UserId,
                ClassId = booking.ClassId,
                ClassSessionId = booking.ClassSessionId
            };
            var createdBooking = await _repo.AddAsync(newBooking);
            return new BookingDto
            {
                Id = createdBooking.Id,
                BookingDate = createdBooking.BookingDate,
                Status = createdBooking.Status,
                UserId = createdBooking.UserId,
                ClassId = createdBooking.ClassId,
                ClassSessionId = createdBooking.ClassSessionId
            };
        }
    }
}
