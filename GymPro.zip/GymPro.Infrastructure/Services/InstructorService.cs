﻿using GymPro.Core.DTOs;
using GymPro.Core.Entities;
using GymPro.Core.Interaces.IRepository;
using GymPro.Core.Interaces.IService;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GymPro.Infrastructure.Service
{
    public class InstructorService : IInstructorService
    {
        private readonly IInstructorRepository _repo;
        public InstructorService(IInstructorRepository repo) => _repo = repo;

        public async Task<List<InstructorDto>> GetAllInstructorsAsync()
        {
            var instructors = await _repo.GetAllInstructorsAsync();
            return instructors.Select(i => new InstructorDto
            {
                Id = i.Id,
                Name = i.FullName,
                Bio = i.Bio,
                //ClassId = i.ClassId
            }).ToList();
        }

        public async Task<InstructorDto?> GetInstructorByIdAsync(int id)
        {
            var i = await _repo.GetInstructorByIdAsync(id);
            if (i == null) return null;

            return new InstructorDto
            {
                Id = i.Id,
                Name = i.FullName,
                Bio = i.Bio,
               // ClassId = i.ClassId
            };
        }

        public async Task<InstructorDto> AddInstructorAsync(InstructorDto dto)
        {
            var instructor = new Instructor
            {
                FullName = dto.Name,
                Bio = dto.Bio,
               // ClassId = dto.ClassId
            };

            var created = await _repo.AddInstructorAsync(instructor);
            dto.Id = created.Id;
            return dto;
        }

        public async Task<InstructorDto?> UpdateInstructorAsync(InstructorDto dto)
        {
            var instructor = new Instructor
            {
                Id = dto.Id,
                FullName = dto.Name,
                Bio = dto.Bio,
               // ClassId = dto.ClassId
            };

            var updated = await _repo.UpdateInstructorAsync(instructor);
            if (updated == null) return null;

            return dto;
        }

        public async Task<bool> DeleteInstructorAsync(int id) => await _repo.DeleteInstructorAsync(id);
    }
}
