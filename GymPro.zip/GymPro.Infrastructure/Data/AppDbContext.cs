﻿using GymPro.Core.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace GymPro.Infrastructure.Data
{

    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<Booking> Bookings { get; set; }
        public DbSet<ClassSession> ClassSessions { get; set; }
        public DbSet<Class> Classes { get; set; }
        public DbSet<Instructor> Instructors { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Unique index to prevent duplicate booking for the same user and session
            modelBuilder.Entity<Booking>()
                .HasIndex(b => new { b.UserId, b.ClassSessionId })
                .IsUnique();
            modelBuilder.Entity<ClassSession>()
    .HasOne(cs => cs.Instructor)
    .WithMany(i => i.ClassSessions)
    .HasForeignKey(cs => cs.InstructorId)
    .OnDelete(DeleteBehavior.Restrict); 
            // 1:N relationship between User and Booking
            modelBuilder.Entity<Booking>()
                .HasOne(b => b.User)
                .WithMany(u => u.Bookings)
                .HasForeignKey(b => b.UserId);
                //.OnDelete(DeleteBehavior.Cascade);

            // 1:N relationship between ClassSession and Booking
            modelBuilder.Entity<Booking>()
                .HasOne(b => b.ClassSession)
                .WithMany(cs => cs.Bookings)
                .HasForeignKey(b => b.ClassSessionId);
                //.OnDelete(DeleteBehavior.Cascade);

            // 1:N relationship between Instructor and Class
            modelBuilder.Entity<Instructor>()
                .HasOne(i => i.Class)
                .WithMany(c => c.Instructors)
                .HasForeignKey(i => i.ClassId);
               // .OnDelete(DeleteBehavior.Cascade);
     
            modelBuilder.Entity<Class>()
                 .Property(c => c.DurationMinutes)
                 .HasPrecision(10, 2); // Adjust as needed

            // 1:N relationship between Class and ClassSession
            modelBuilder.Entity<ClassSession>()
                .HasOne(cs => cs.Class)
                .WithMany(c => c.ClassSessions)
                .HasForeignKey(cs => cs.ClassId);
              //  .OnDelete(DeleteBehavior.Cascade);
        }
      /*  protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server=RamaAL-Momani\\SQLEXPRESS01;Database=GymProDb;Trusted_Connection=True;");
            }
        }*/




    }
}
