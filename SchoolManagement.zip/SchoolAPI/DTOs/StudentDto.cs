﻿namespace SchoolAPI.DTOs
{
    public class StudentDto
    {
        public string? Name { get; set; }
        public DateTime BirthDate { get; set; }
    }
}
