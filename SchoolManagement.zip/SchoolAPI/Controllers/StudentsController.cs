﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace SchoolAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentsController : ControllerBase
    {


        [HttpGet]
        public async Task<IActionResult> GetAllStudents()
        {
            // Logic to get all students
            return Ok(); // Placeholder for actual data
        }

    }

}