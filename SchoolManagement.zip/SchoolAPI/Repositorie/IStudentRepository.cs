﻿using SchoolAPI.Models;

namespace SchoolAPI.Repositorie
{
    public interface IStudentRepository
    {
        Task<List<Student>> GetAllAsync();
        Task<Student> GetByIdAsync(int id);
        Task AddAsync(Student student);
        void Update(Student student);
        void Delete(Student student);
        Task SaveAsync();
    }

}
