﻿using SchoolAPI.Models;
using SchoolAPI.Repositorie;

namespace SchoolAPI.Services
{
    public class StudentService
    {
        private readonly IStudentRepository _repo;
        public StudentService(IStudentRepository repo) { _repo = repo; }

        public async Task<List<Student>> GetAllStudentsAsync() => await _repo.GetAllAsync();
        public async Task AddStudentAsync(Student student)
        {
            // Example: Validate data before adding
            if (string.IsNullOrWhiteSpace(student.Name))
                throw new Exception("Name is required");
            await _repo.AddAsync(student);
            await _repo.SaveAsync();
        }
    }
}
