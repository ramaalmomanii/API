﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using School.Core.DTOs;
using School.Core.Entities;


namespace School.Core.DTOs;

public class StdCourseDto
{
    //Id = s.Id,StudentId = s.StudentId,CourseId = s.CourseId MarkOfStd = s.MarkOfStd,
           // DateOfRegister = s.DateOfRegister
    public int Id { get; set; }
    public int StudentId { get; set; }
    public String? StudentFName { get; set; }
    
    public String? StudentLName { get; set; }

    public int CourseId { get; set; }
    public decimal MarkOfStd { get; set; }
    public DateTime DateOfRegister { get; set; }
   public int StdCourseId { get; set; }
}
