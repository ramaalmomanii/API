﻿using School.Core.Entities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace School.Core.Entities
{
    public class Role
    {
        //Id, Name, ICollection<User>,admin, student, 

        public int RoleId { get; set; }
        
        public string RoleName { get; set; } // e.g., "Admin", "Student", "Teacher"
        public ICollection<Login> Logins { get; set; } = new List<Login>();

    }
}
