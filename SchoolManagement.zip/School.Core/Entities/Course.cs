﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace School.Core.Entities
{
    public class Course
    {
        //Id, Title(Name), CategoryId, Category, ICollection<StdCourse>

        public int CourseId { get; set; }
        public string? CourseName { get; set; }
        public int? CategoryId { get; set; }
       

        public Category? Category { get; set; }
        public ICollection<StdCourse>? StdCourses { get; set; }
        public string? Description { get; set; }
    }
}
