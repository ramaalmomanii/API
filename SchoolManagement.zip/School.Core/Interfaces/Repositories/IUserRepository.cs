﻿using School.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace School.Core.Interfaces.Repositories
{
    public interface IUserRepository
    {
        Task<IEnumerable<Login>> GetAllAsync();
        Task<Login?> GetByIdAsync(int id);
        Task<Login?> GetByUsernameAsync(string username);
        Task AddAsync(Login user);
        Task UpdateAsync(Login user);
        Task DeleteAsync(int id);
    }

}
