﻿using School.Core.DTOs;
using School.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace School.Core.Interfaces.Repositories
{
    public interface IStdCourseRepository
    {
        Task<IEnumerable<StdCourse>> GetAllAsync();
        Task<StdCourse?> GetByIdAsync(int id);
        Task AddAsync(StdCourse stdCourse);
        Task UpdateAsync(StdCourse stdCourse);
        Task DeleteAsync(int id);
        Task<bool> ExistsAsync(int id);
        Task<bool> IsDuplicateEnrollmentAsync(int studentId, int courseId);
        Task<IEnumerable<StdCourse>> GetByStudentIdAsync(int studentId);
        Task SaveChangesAsync();
    }
}

