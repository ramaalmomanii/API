﻿using School.Core.DTOs;
using School.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace School.Core.Interfaces.Repositories
{
    public interface IStudentRepository
    {
        Task<IEnumerable<Student>> GetAllAsync();
        Task<Student?> GetByIdAsync(int id);
        Task AddAsync(Student student);
        Task UpdateAsync(Student student);
        Task DeleteAsync(int id);
        Task<bool> ExistsAsync(int id);
        Task<IEnumerable<StdCourse>> GetByStudentIdAsync(int studentId);
        Task SaveChangesAsync();
        
        Task<Student?> GetByIdWithCoursesAsync(int studentId);
        Task AddStudentsync(StudentDto studentDto);
        Task AddAsync(StudentDto studentDto);
    }
}

