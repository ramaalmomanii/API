﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using School.Core.Entities;

namespace School.Core.Interfaces.Repositories
{
    public interface ILoginRepository
    {
        Task<IEnumerable<Login>> GetAllAsync();
        Task<Login?> GetByIdAsync(int id);
        Task AddAsync(Login login);
        Task UpdateAsync(Login login);
        Task DeleteAsync(int id);
        //Task GetByUsernameAsync(string username);
        Task<Login?> GetByUsernameAsync(string username);

    }
}
