﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using School.Core.DTOs;
using School.Core.Entities;

public interface IStdCourseService
{
    Task<IEnumerable<StdCourseDto>> GetAllAsync();
    //Task<StdCourseDto?> GetByIdAsync(int id);
    Task AddAsync(StdCourseDto dto);
    Task DeleteAsync(int id);
    Task UpdateAsync(StdCourseDto dto);
    Task<bool> IsDuplicateEnrollmentAsync(int studentId, int courseId);

    Task<IEnumerable<StdCourseDto>> GetByStudentIdAsync(int studentId);

    // Task<IEnumerable<StdCourseDto>> GetByIdAsync(int studentId);
    //Task<StdCourseDto?> GetByIdAsync(int id);
}

