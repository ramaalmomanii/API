﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using School.Core.DTOs;

public interface IRoleService
{
    Task AddAsync(RoleDto dto);
    Task DeleteAsync(int id);
    Task<IEnumerable<RoleDto>> GetAllAsync();
    Task<RoleDto>  GetByIdAsync(int id);
    Task UpdateAsync(RoleDto dto);
}

