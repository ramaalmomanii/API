﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using School.Core.DTOs;

public interface ILoginService
{
    Task<LoginDto> GetByUsernameAsync(string username);
    Task AddAsync(LoginDto dto);
    Task DeleteAsync(int id);
    Task UpdateAsync(LoginDto dto);
    Task<LoginDto> GetByIdAsync(int id);
    Task<LoginDto?> GetAllAsync();
}
