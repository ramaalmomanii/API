﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using School.Core.DTOs;

public interface ICategoryService
{

    Task<IEnumerable<CategoryDto>> GetAllAsync();
    Task<CategoryDto> GetByIdAsync(int id);
    Task AddAsync(CategoryDto category);
    Task UpdateAsync(CategoryDto category);
    Task DeleteAsync(int id);
}

