﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using School.Core.Interfaces.Services;
using School.Core.DTOs;

namespace School.Core.Interfaces.Services
{
    /// <summary>
    /// Interface for Course Service
    /// </summary>
    /// <remarks>
    /// This interface defines the methods for managing courses in the system.
    /// </remarks>

public interface ICourseService
{
    Task<IEnumerable<CourseDto>> GetAllAsync();
    Task<CourseDto> GetByIdAsync(int id);
    Task AddAsync(CourseDto dto);
    Task UpdateAsync(CourseDto dto);
    Task DeleteAsync(int id);
    
}
}