﻿using Microsoft.AspNetCore.Mvc;

namespace SchoolManagement
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
