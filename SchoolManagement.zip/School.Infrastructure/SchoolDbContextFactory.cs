﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using School.Infrastructure.Data;

namespace School.Infrastructure
{
    public class SchoolDbContextFactory : IDesignTimeDbContextFactory<SchoolDbContext>
    {
        public SchoolDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<SchoolDbContext>();
            optionsBuilder.UseSqlServer("Server=localhost\\SQLEXPRESS02 ;Database=SchoolDb;Trusted_Connection=True;TrustServerCertificate=True");

            return new SchoolDbContext(optionsBuilder.Options);
        }
    }
}
