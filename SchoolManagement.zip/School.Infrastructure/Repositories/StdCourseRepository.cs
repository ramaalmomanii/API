﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.EntityFrameworkCore;
using School.Core.DTOs;
using School.Core.Entities;
using School.Core.Interfaces.Repositories;
using School.Infrastructure.Data;


namespace School.Infrastructure.Repositories
{
    public class StdCourseRepository : IStdCourseRepository
    {
        private readonly SchoolDbContext _context;

        public StdCourseRepository(SchoolDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<StdCourse>> GetAllAsync()
        {
            return await _context.StdCourses
                .Include(sc => sc.Student)
                .Include(sc => sc.Course)
                .ToListAsync();
        }

        public async Task<StdCourse?> GetByIdAsync(int id)
        {
            return await _context.StdCourses
                .Include(sc => sc.Student)
                .Include(sc => sc.Course)
                .FirstOrDefaultAsync(sc => sc.Id == id);
        }
        public async Task SaveChangesAsync()
        {
            await _context.SaveChangesAsync();
        }


        public async Task AddAsync(StdCourse stdCourse)
        {
            await _context.StdCourses.AddAsync(stdCourse);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(StdCourse stdCourse)
        {
            _context.StdCourses.Update(stdCourse);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var stdCourse = await _context.StdCourses.FindAsync(id);
            if (stdCourse != null)
            {
                _context.StdCourses.Remove(stdCourse);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<IEnumerable<StdCourse>> GetByStudentIdAsync(int studentId)
        {
            return await _context.StdCourses
                .Include(sc => sc.Student)
                .Include(sc => sc.Course)
                .Where(sc => sc.StudentId == studentId)
                .ToListAsync();
        }

        public async Task<bool> ExistsAsync(int id)
        {
            return await _context.StdCourses.AnyAsync(sc => sc.Id == id);
        }

        public async Task<bool> IsDuplicateEnrollmentAsync(int studentId, int courseId)
        {
            return await _context.StdCourses
                .AnyAsync(sc => sc.StudentId == studentId && sc.CourseId == courseId);
        }
    }
}
