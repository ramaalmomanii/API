﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.EntityFrameworkCore;
using School.Core.Entities;
using School.Core.Interfaces.Repositories;
using School.Infrastructure.Data;



namespace School.Infrastructure.Repositories
{
    public class LoginRepository : ILoginRepository
    {
        private readonly SchoolDbContext _context;

        public LoginRepository(SchoolDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Login>> GetAllAsync()
        {
            return await _context.Logins.ToListAsync();
        }

        public async Task<Login?> GetByIdAsync(int id)
        {
            return await _context.Logins.FindAsync(id);
        }

        public async Task AddAsync(Login login)
        {
            await _context.Logins.AddAsync(login);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Login login)
        {
            _context.Logins.Update(login);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var login = await _context.Logins.FindAsync(id);
            if (login != null)
            {
                _context.Logins.Remove(login);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<Login?> GetByUsernameAsync(string username)
        {
            return await _context.Logins.FirstOrDefaultAsync(l => l.UserName == username);
        }

        // Removed the invalid 'public' modifier from the explicit interface implementation
        async Task<Login?> ILoginRepository.GetByUsernameAsync(string username)
        {
            return await _context.Logins
                .Include(l => l.Role) // Include Role if needed
                .FirstOrDefaultAsync(l => l.UserName == username);
        }
    }
}

