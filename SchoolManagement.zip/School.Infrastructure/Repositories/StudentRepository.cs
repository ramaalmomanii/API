﻿using Microsoft.EntityFrameworkCore;
using School.Core.DTOs;
using School.Core.Entities;
using School.Core.Interfaces.Repositories;
using School.Infrastructure.Data;

namespace School.Infrastructure.Repositories
{

public class StudentRepository : IStudentRepository
    {
        private readonly SchoolDbContext _context;

        public StudentRepository(SchoolDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Student>> GetAllAsync()
        {
            return await _context.Students.ToListAsync();
        }

        public async Task<Student?> GetByIdAsync(int id)
        {
            return await _context.Students.FindAsync(id);
        }

        public async Task AddAsync(Student student)
        {
            await _context.Students.AddAsync(student);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Student student)
        {
            var existingStudent = await _context.Students.FindAsync(student.StudentId);

            if (existingStudent == null)
                throw new KeyNotFoundException($"Student with ID {student.StudentId} not found.");


            existingStudent.FirstName = student.FirstName;
            existingStudent.LastName = student.LastName ;

            existingStudent.Email = student.Email;
            existingStudent.DateOfBirth = student.DateOfBirth;
           

            await _context.SaveChangesAsync();
        }


        public async void DeleteAsync(Student student)
        {
            _context.Students.Remove(student);
           await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var student = await _context.Students.FindAsync(id);
            if (student != null)
            {
                _context.Students.Remove(student);
                await _context.SaveChangesAsync(); 
            }
        }
        public async Task<Student?> GetByIdWithCoursesAsync(int studentId)
        {
            return await _context.Students
                .Include(s => s.StdCourses)
                .ThenInclude(sc => sc.Course)
                .FirstOrDefaultAsync(s => s.StudentId == studentId);
        }


        public async Task<bool> ExistsAsync(int id)
        {
            return await _context.Students.AnyAsync(s => s.StudentId == id);
            
        }

       

        public Task<IEnumerable<StdCourse>> GetByStudentIdAsync(int studentId)
        {
            throw new NotImplementedException();
        }

        public async Task<int> SaveChangesAsync()
        {
            return await _context.SaveChangesAsync();
        }

        public Task AddStudentsync(StudentDto studentDto)
        {
            return Task.CompletedTask;
        }

        public Task AddAsync(StudentDto studentDto)
        {
            throw new NotImplementedException();
        }

        Task IStudentRepository.SaveChangesAsync()
        {
            return SaveChangesAsync();
        }
    }
}
