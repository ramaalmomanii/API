﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using School.Core.DTOs;
using School.Core.Entities;
using School.Core.Interfaces;
using School.Core.Interfaces.Repositories;


namespace School.Infrastructure.Services
{
    public class LoginService : ILoginService
{
    private readonly ILoginRepository _repo;

    public LoginService(ILoginRepository repo)
    {
        _repo = repo;
    }

    public async Task<LoginDto?> GetByUsernameAsync(string username)
    {
        var login = await _repo.GetByUsernameAsync(username);
        return login == null ? null : new LoginDto
        {
            LoginId = login.Id,
            Username = login.UserName,
            Password = login.Password,
            RoleId = login.RoleId,
            StudentId = login.StudentId
        };
    }

    public async Task AddAsync(LoginDto dto)
    {
        var login = new Login
        {
            UserName = (string)dto.Username,
            Password = dto.Password,
            RoleId = dto.RoleId,
            StudentId = dto.StudentId
        };
        await _repo.AddAsync(login);
    }

    public Task DeleteAsync(int id)
    {
        throw new NotImplementedException();
    }

    public Task UpdateAsync(LoginDto dto)
    {
        throw new NotImplementedException();
    }

    public Task GetByIdAsync(int id)
    {
        throw new NotImplementedException();
    }

    public Task<object?> GetAllAsync()
    {
        throw new NotImplementedException();
    }

        Task<LoginDto> ILoginService.GetByIdAsync(int id)
        {
            throw new NotImplementedException();
        }

        Task<LoginDto?> ILoginService.GetAllAsync()
        {
            throw new NotImplementedException();
        }
    }

    }