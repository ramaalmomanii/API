﻿using School.Core.DTOs;
using School.Core.Entities;
using School.Core.Interfaces.Repositories;
using School.Core.Interfaces.Services;

namespace School.Infrastructure.Services
{
    public class StudentService : IStudentService
    {
        private readonly IStudentRepository _repository;

        public StudentService(IStudentRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<Student>> GetAllStudentsAsync()
        {
            var students = await _repository.GetAllAsync();
            return students.Select(s => new Student
            {
                StudentId = s.StudentId,
                FirstName = s.FirstName,
                LastName = s.LastName,
                DateOfBirth = s.DateOfBirth
            });
        }

        public async Task<Student?> GetStudentByIdAsync(int id)
        {
            var student = await _repository.GetByIdAsync(id);
            return student != null ? new Student
            {
                StudentId = student.StudentId,
                FirstName = student.FirstName,
                LastName = student.LastName,
                DateOfBirth = student.DateOfBirth
            } : null;
        }   

       

        public async Task UpdateStudentAsync(Student student)
        {
          if (student == null) throw new ArgumentNullException(nameof(student));
            var existingStudent = await _repository.GetByIdAsync(student.StudentId);
            if (existingStudent != null)
            {
                existingStudent.FirstName = student.FirstName;
                existingStudent.LastName = student.LastName;
                existingStudent.DateOfBirth = student.DateOfBirth;
                await _repository.UpdateAsync(existingStudent);
                await _repository.SaveChangesAsync();
            }
        }

        public async Task DeleteStudentAsync(int id)
        {
            var student = await _repository.GetByIdAsync(id);
            if (student != null)
            {
                await _repository.DeleteAsync(id); 
            }
            await _repository.SaveChangesAsync();
        }

        public async Task<IEnumerable<StudentDto>> GetAllAsync()
        {
            var students = await _repository.GetAllAsync();
            return students.Select(s => new StudentDto
            {
                StudentId = s.StudentId,
                FirstName = s.FirstName,
                LastName = s.LastName,
                DateOfBirth = s.DateOfBirth
            });
        }

        public async Task<StudentDto> GetByIdAsync(int id)
        {
            if (id <= 0) throw new ArgumentException("Invalid student ID.", nameof(id));

            var student = await _repository.GetByIdAsync(id);
            if (student == null) return null;

            return new StudentDto
            {
                StudentId = student.StudentId,
                FirstName = student.FirstName,
                LastName = student.LastName,
                DateOfBirth = student.DateOfBirth
            };
        }
        public async Task<IEnumerable<CourseWithGradeDto>> GetCoursesWithGradesAsync(int studentId)
        {
            var student = await _repository.GetByIdWithCoursesAsync(studentId); 
            if (student == null || student.StdCourses == null) return Enumerable.Empty<CourseWithGradeDto>();

            return student.StdCourses.Select(sc => new CourseWithGradeDto
            {
                CourseId = sc.Course.CourseId,
                CourseName = sc.Course.CourseName,
                MarkOfStd = (double?)sc.MarkOfStd
            });
        }

        public async Task AddAsync(StudentDto studentDto)
        {
            if (studentDto == null)
                throw new ArgumentNullException(nameof(studentDto));

            var student = new Student
            {
                FirstName = studentDto.FirstName,
                LastName = studentDto.LastName,
                DateOfBirth = studentDto.DateOfBirth
            };

            await _repository.AddAsync(student);
            await _repository.SaveChangesAsync();
        }


        public async Task UpdateAsync(StudentDto studentDto)
        {
            if (studentDto == null)
                throw new ArgumentNullException(nameof(studentDto));

            var existingStudent = await _repository.GetByIdAsync(studentDto.StudentId);
            if (existingStudent == null)
                throw new InvalidOperationException("Student not found.");

            existingStudent.FirstName = studentDto.FirstName;
            existingStudent.LastName = studentDto.LastName;
            existingStudent.DateOfBirth = studentDto.DateOfBirth;

           // await _repository.UpdateAsync(existingStudent);
            await _repository.SaveChangesAsync();
        }


        public async Task DeleteAsync(int id)
        {
            var student = await _repository.GetByIdAsync(id);
            if (student == null)
                throw new InvalidOperationException("Student not found.");

            await _repository.DeleteAsync(id);
            await _repository.SaveChangesAsync();
        }




    }
}
