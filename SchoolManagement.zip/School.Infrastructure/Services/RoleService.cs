﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using School.Core.DTOs;
using School.Core.Interfaces.Repositories;
using School.Infrastructure.Repositories;




namespace School.Infrastructure.Services
{
    public class RoleService : IRoleService
    {
        private readonly IRoleRepository _repo;

        public RoleService(IRoleRepository repo)
        {
            _repo = repo;
        }

        public Task AddAsync(RoleDto dto)
        {
            throw new NotImplementedException();
        }

        public Task DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<RoleDto>> GetAllAsync()
        {
            var roles = await _repo.GetAllAsync();
            return roles.Select(r => new RoleDto
            {
                RoleId = r.RoleId,
                RoleName = r.RoleName
            });
        }

        public Task GetByIdAsync(int id)
        {
            throw new NotImplementedException();
        }

        public Task UpdateAsync(RoleDto dto)
        {
            throw new NotImplementedException();
        }

        Task<RoleDto> IRoleService.GetByIdAsync(int id)
        {
            throw new NotImplementedException();
        }
    }

}