﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using School.Core.DTOs;
using School.Core.Entities;
using School.Core.Interfaces.Services;
using School.Core.Interfaces.Repositories;


namespace School.Infrastructure.Services
{
    public class CourseService : ICourseService
    {
        private readonly ICourseRepository _repo;

        public CourseService(ICourseRepository repo)
        {
            _repo = repo;
        }

        public async Task<IEnumerable<CourseDto>> GetAllAsync()
        {
            var courses = await _repo.GetAllAsync();
            return courses.Select(c => new CourseDto
            {
                CourseId = c.CourseId,
                CourseName = c.CourseName,
                Description = c.Description,
                CategoryId = (int)c.CategoryId
            });
        }

        public async Task<CourseDto?> GetByIdAsync(int id)
        {
            var course = await _repo.GetByIdAsync(id);
            return course == null ? null : new CourseDto
            {
                CourseId = course.CourseId,
                CourseName = course.CourseName,
                Description = course.Description,
                CategoryId = (int)course.CategoryId
            };
        }

        public async Task AddAsync(CourseDto dto)
        {
            var course = new Course
            {
                CourseName = dto.CourseName,
                Description = dto.Description,
                CategoryId = dto.CategoryId
            };
            await _repo.AddAsync(course);
             
        }

        public async Task UpdateAsync(CourseDto courseDto)
        {
            if (courseDto == null)
                throw new ArgumentNullException(nameof(courseDto));

            var existingCourse = await _repo.GetByIdAsync(courseDto.CourseId);
            if (existingCourse == null)
                throw new InvalidOperationException("Course not found.");

            existingCourse.CourseName = courseDto.CourseName;
           // existingCourse.CreditHours = courseDto.CreditHours;
            existingCourse.CategoryId = courseDto.CategoryId;

            await _repo.UpdateAsync(existingCourse);
            await _repo.SaveChangesAsync();
        }


        public async Task DeleteAsync(int id)
        {
            if (await _repo.ExistsAsync(id))
            {
                await _repo.DeleteAsync(id);
            }
            else
            {
                throw new KeyNotFoundException($"Course with ID {id} not found.");
            }
        }
    }

}

