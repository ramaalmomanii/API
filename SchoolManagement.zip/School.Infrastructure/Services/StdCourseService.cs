﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using School.Core.DTOs;
using School.Core.Entities;
using School.Core.Interfaces.Repositories;
using School.Infrastructure.Repositories;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

public class StdCourseService : IStdCourseService
{
    private readonly IStdCourseRepository _repo;

    public StdCourseService(IStdCourseRepository repo)
    {
        _repo = repo;
    }

    public async Task<IEnumerable<StdCourseDto>> GetAllAsync()
    {
        var sc = await _repo.GetAllAsync();
        return sc.Select(s => new StdCourseDto
        {
            Id = s.Id,
            StudentId = s.StudentId,
            CourseId = s.CourseId,
            MarkOfStd = s.MarkOfStd,
            DateOfRegister = s.DateOfRegister
        });
    }

    public async Task<StdCourseDto?> GetByIdAsync(int id)
    {
        var s = await _repo.GetByIdAsync(id);
        if (s == null) return null;

        return new StdCourseDto
        {
            Id = s.Id,
            StudentId = s.StudentId,
            CourseId = s.CourseId,
            MarkOfStd = s.MarkOfStd,
            DateOfRegister = s.DateOfRegister
        };
    }

    public async Task AddAsync(StdCourseDto dto)
    {
        var sc = new StdCourse
        {
            StudentId = dto.StudentId,
            CourseId = dto.CourseId,
            MarkOfStd = dto.MarkOfStd,
            DateOfRegister = dto.DateOfRegister
        };
        await _repo.AddAsync(sc);
    }

    public async Task DeleteAsync(int id)
    {
        var stdCourse = await _repo.GetByIdAsync(id);
        if (stdCourse == null)
            throw new InvalidOperationException("Student not found.");

        await _repo.DeleteAsync(id);
        await _repo.SaveChangesAsync();
    }

    public async Task UpdateAsync(StdCourseDto dto)
    {
        var existing = await _repo.GetByIdAsync(dto.Id);
        if (existing == null)
            throw new InvalidOperationException("Enrollment not found.");

        existing.StudentId = dto.StudentId;
        existing.CourseId = dto.CourseId;
        existing.MarkOfStd = dto.MarkOfStd;
        existing.DateOfRegister = dto.DateOfRegister;

        await _repo.UpdateAsync(existing);
    }


    public async Task<bool> IsDuplicateEnrollmentAsync(int studentId, int courseId)
    {
        return await _repo.IsDuplicateEnrollmentAsync(studentId, courseId);
    }

    public async Task<IEnumerable<StdCourseDto>> GetByStudentIdAsync(int studentId)
    {
        var list = await _repo.GetByStudentIdAsync(studentId);
        return list.Select(s => new StdCourseDto
        {
            Id = s.Id,
            StudentId = s.StudentId,
            CourseId = s.CourseId,
            MarkOfStd = s.MarkOfStd,
            DateOfRegister = s.DateOfRegister
        });
    }
}
