﻿using School.Core.DTOs;
using School.Core.Entities;
using School.Core.Interfaces.Repositories;
using School.Core.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace School.Infrastructure.Services
{
    public class CategoryService : ICategoryService
    {
        private readonly ICategoryRepository _repo;

        public CategoryService(ICategoryRepository repo)
        {
            _repo = repo;
        }


        public async Task<IEnumerable<CategoryDto>> GetAllAsync()
        {
            var cats = await _repo.GetAllAsync();
            return cats.Select(c => new CategoryDto
            {
                CategoryId = c.CategoryId,
                CategoryName = c.CategoryName
                
            });
        }

        public async Task<CategoryDto> GetByIdAsync(int id)
        {
            var c = await _repo.GetByIdAsync(id);
            if (c == null) return null;
            return new CategoryDto
            {
                CategoryId = c.CategoryId,
                CategoryName = c.CategoryName
                
            };
        }

        public async Task AddAsync(CategoryDto dto)
        {
            var cat = new Category { CategoryName = dto.CategoryName };
            await _repo.AddAsync(cat);
        }

        public async Task UpdateAsync(CategoryDto dto)
        {
            var cat = new Category
            {
                CategoryId = dto.CategoryId,
                CategoryName = dto.CategoryName
               
            };
            await _repo.UpdateAsync(cat);
        }

        public async Task DeleteAsync(int id)
        {
            await _repo.DeleteAsync(id);
        }
    }

}


