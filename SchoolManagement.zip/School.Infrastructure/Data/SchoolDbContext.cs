﻿using Microsoft.EntityFrameworkCore;
using School.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace School.Infrastructure.Data
{
    public class SchoolDbContext : DbContext
    {
        public SchoolDbContext(DbContextOptions<SchoolDbContext> options) : base(options) { }

        public DbSet<Student> Students { get; set; }
        public DbSet<Course> Courses { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Login> Logins  { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<StdCourse> StdCourses { get; set; }
       

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // 🔹 Category - Course (1:M)
            modelBuilder.Entity<Category>()
                .HasMany(c => c.Courses)
                .WithOne(c => c.Category)
                .HasForeignKey(c => c.CategoryId)
                .OnDelete(DeleteBehavior.Cascade);

            // 🔹 Course - StdCourse (1:M)
            modelBuilder.Entity<Course>()
                .HasMany(c => c.StdCourses)
                .WithOne(sc => sc.Course)
                .HasForeignKey(sc => sc.CourseId)
                .OnDelete(DeleteBehavior.Cascade);

            // 🔹 Student - StdCourse (1:M)
            modelBuilder.Entity<Student>()
                .HasMany(s => s.StdCourses)
                .WithOne(sc => sc.Student)
                .HasForeignKey(sc => sc.StudentId)
                .OnDelete(DeleteBehavior.Cascade);

            // 🔹 تحديد شكل العلامة MarkOfStd
            modelBuilder.Entity<StdCourse>()
                .Property(sc => sc.MarkOfStd)
                .HasPrecision(5, 2); // مثلا 95.75

            // 🔹 Role - User (1:M)
            modelBuilder.Entity<Role>()
                .HasMany(r => r.Logins)
                .WithOne(u => u.Role)
                .HasForeignKey(u => u.RoleId)
                .OnDelete(DeleteBehavior.Restrict);
            //العلاقة بين الرول واليوزر
            modelBuilder.Entity<Role>()
            .HasMany(r => r.Logins)
            .WithOne(l => l.Role)
            .HasForeignKey(l => l.RoleId)
            .OnDelete(DeleteBehavior.Restrict);

            // تغيير تلقائي 
            modelBuilder.Entity<Login>()
            .Property(l => l.CreatedAt)
               .HasDefaultValueSql("GETDATE()");

            modelBuilder.Entity<Login>()
                .Property(l => l.UpdatedAt)
                .HasDefaultValueSql("GETDATE()");


            // PK 🔹 تحديد البرايمري كي
            modelBuilder.Entity<Student>().HasKey(s => s.StudentId);
            modelBuilder.Entity<Course>().HasKey(c => c.CourseId);
            modelBuilder.Entity<Category>().HasKey(c => c.CategoryId);
            modelBuilder.Entity<StdCourse>().HasKey(sc => sc.Id);
            modelBuilder.Entity<Role>().HasKey(r => r.RoleId);
            modelBuilder.Entity<Login>().HasKey(u => u.Id);

            base.OnModelCreating(modelBuilder);
        }

    }
}
